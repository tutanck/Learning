## [Tourism application](https://github.com/algolia/instantsearch-ios-examples/tree/master/Icebnb)
<img src="../docs/icebnb.gif" align="right" width="300"/>

Example of a bed and breakfast search interface.

- Search a place by the **user's location** aka geo-search
- Filter with Numeric filters by **price**
- Custom interaction for linking the search results with `GoogleMap` and `MapFragment`

