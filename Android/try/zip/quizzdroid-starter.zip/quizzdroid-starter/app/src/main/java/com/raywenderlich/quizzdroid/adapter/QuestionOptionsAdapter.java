package com.raywenderlich.quizzdroid.adapter;

/*
 * Copyright (c) 2016 Razeware LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.raywenderlich.quizzdroid.R;

import java.util.List;
import java.util.Map;

public class QuestionOptionsAdapter extends BaseAdapter {

  private final List<String> mOptions;
  private Map<String,Integer> mAnswerCounts;

  public QuestionOptionsAdapter(List<String> options, Map<String,Integer> answerCounts) {
    mOptions = options;
    mAnswerCounts = answerCounts;
  }

  public void setAnswerCounts(Map<String,Integer> answerCounts)  {
    mAnswerCounts = answerCounts;
  }

  @Override
  public int getCount() {
    return mOptions.size();
  }

  @Override
  public String getItem(int position) {
    return mOptions.get(position);
  }

  @Override
  public long getItemId(int position) {
    return position;
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent) {
    if (convertView == null) {
      LayoutInflater inflater = LayoutInflater.from(parent.getContext());
      convertView = inflater.inflate(R.layout.item_answer_option, parent, false);
    }

    TextView answerView = (TextView) convertView.findViewById(R.id.textOption);
    TextView countView = (TextView) convertView.findViewById(R.id.textNum);

    String text = getItem(position);
    answerView.setText(text);

    Integer count = 0;

    if (mAnswerCounts != null) {
      count = mAnswerCounts.get(text);
    }

    countView.setText(count.toString());

    return convertView;
  }
}
