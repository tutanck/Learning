package com.example.ajoan.utils;

/**
 * Created by Joan on 26/03/2017.
 */

public class WebAppDirectory {

    public static String serverUrl ="http://192.168.1.91:8080/Essais0";

    public static String routerUrl ="http://192.168.1.91:8080/Essais0/jz/app/routes";

    public static String emailChk="check_email";

    public static String usernameChk="check_username";

    public static String signup="signup";

    public static String signin="signin";

    public static String signout="signout";

    public static String forgotPass="recover_account";


}
