package com.example.ajoan.utils.jeez.reqstr;

public class AppRouterNotLoadedException extends Exception {
        AppRouterNotLoadedException(String msg) { super(msg); }
    }