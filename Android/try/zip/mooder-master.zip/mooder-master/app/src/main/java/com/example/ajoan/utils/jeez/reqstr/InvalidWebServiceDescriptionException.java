package com.example.ajoan.utils.jeez.reqstr;

public class InvalidWebServiceDescriptionException extends Exception {
        InvalidWebServiceDescriptionException(String msg) { super(msg); }
    }