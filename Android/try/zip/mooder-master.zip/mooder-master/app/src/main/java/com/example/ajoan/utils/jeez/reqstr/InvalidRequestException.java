package com.example.ajoan.utils.jeez.reqstr;

public class InvalidRequestException extends Exception {
        InvalidRequestException(String msg) { super(msg); }
    }