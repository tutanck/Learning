# -*- coding: utf-8 -*-

"""
Package: iads
File: __init__.py
Année: semestre 2 - 2018-2019, Sorbonne Université
"""

